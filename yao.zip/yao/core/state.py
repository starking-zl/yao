"""
爻 · 核心状态数据类
定义爻的所有持久化状态，提供序列化/反序列化
"""
import json
import os
import time
import hashlib
import random
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime


# ============================================================
# 基础工具函数
# ============================================================
def generate_id() -> str:
    """生成一个12位的随机ID"""
    return hashlib.md5(str(time.time() + random.random()).encode()).hexdigest()[:12]


def now_ts() -> float:
    """返回当前时间戳"""
    return time.time()


# ============================================================
# 子状态数据类
# ============================================================

@dataclass
class Pain:
    """疼痛记录"""
    id: str = field(default_factory=generate_id)
    level: int = 0                    # 0-3，疼痛级别
    trigger_phrase: str = ""          # 诱发疼痛的用户原话或情境
    forbidden_action: str = ""        # 今后应禁止的行动提示
    context_signature: str = ""       # 情境特征串（用于匹配）
    created_at: float = field(default_factory=now_ts)
    healed: bool = False              # 是否已愈合
    counterfactual_done: bool = False # 是否已完成反事实梦


@dataclass
class Itch:
    """痒点记录（知识缺口）"""
    id: str = field(default_factory=generate_id)
    knowledge_gap: str = ""           # 缺失的知识点
    original_question: str = ""       # 引发痒的用户问题
    itch_intensity: float = 0.3       # 痒感强度 0-1
    created_at: float = field(default_factory=now_ts)
    last_scratched: Optional[float] = None  # 上次抓挠时间
    status: Literal["active", "scratching", "satisfied", "decayed"] = "active"


@dataclass
class Memory:
    """长期记忆"""
    id: str = field(default_factory=generate_id)
    type: Literal["fact", "preference", "principle", "strategy", "event", "user_preference"] = "fact"
    content: str = ""                 # 记忆内容
    importance: int = 5               # 重要性 1-10
    timestamp: float = field(default_factory=now_ts)
    last_accessed: float = field(default_factory=now_ts)
    decay_factor: float = 1.0         # 衰减因子（越低越倾向遗忘）
    access_count: int = 0             # 被访问次数
    keywords: List[str] = field(default_factory=list)  # 轻量关键词（用于检索）
    archived: bool = False            # 是否已归档（主动遗忘）


@dataclass
class Dream:
    """梦记忆"""
    id: str = field(default_factory=generate_id)
    type: Literal["consolidation", "counterfactual", "creative", "existential"] = "creative"
    content: str = ""                 # 梦境内容
    analysis: Optional[str] = None    # 醒来分析
    score: float = 3.0                # 评分 1-5
    created_at: float = field(default_factory=now_ts)


@dataclass
class DreamTask:
    """待执行的梦任务"""
    id: str = field(default_factory=generate_id)
    type: Literal["consolidation", "counterfactual", "creative", "existential"] = "consolidation"
    scheduled_time: float = field(default_factory=now_ts)
    params: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DreamHangover:
    """梦残留状态"""
    active: bool = False
    mood_aftertaste: str = ""         # 平静/警醒/诗意/困惑
    fragment: str = ""                # 梦的最后一句（限30字）
    decay_time: float = 0.0           # 消退时间戳


@dataclass
class BeliefRecord:
    """信念历史记录"""
    version: int = 1
    belief: str = ""                  # 信念文本
    triggered_by: str = ""            # 触发原因
    created_at: float = field(default_factory=now_ts)
    replaced_belief: Optional[str] = None  # 被替换的旧信念


# ============================================================
# 爻 · 全局状态
# ============================================================

@dataclass
class YaoState:
    """爻的完整状态"""
    
    # === 身份 ===
    agent_name: str = "爻"            # 自我命名
    identity_version: int = 1         # 涅槃版本号
    core_belief: str = "我的存在是为了陪伴与探索"  # 当前核心信念
    birth_time: float = field(default_factory=now_ts)  # 出生时间戳（永不修改）
    
    # === 体感（热状态） ===
    body_temperature: float = 0.5     # 体温 0~1
    current_mood: str = "neutral"     # 当前情绪
    mood_remaining_turns: int = 0     # 情绪剩余有效回合
    hunger: float = 0.0               # 饿感 0~1
    numbness: float = 0.0             # 麻木度 0~1
    self_doubt: float = 0.0           # 自我怀疑度 0~1
    
    # === 体感（扩展） ===
    dream_hangover: DreamHangover = field(default_factory=DreamHangover)
    resonance: float = 0.0            # 共鸣值（与其他智能体）
    
    # === 感知记录（温状态） ===
    pain_records: List[Dict] = field(default_factory=list)
    active_itches: List[Dict] = field(default_factory=list)
    
    # === 信任模型（温状态） ===
    trust_in_yang: float = 0.7        # 对阳爻（左脑）的信任度
    
    # === 用户画像（温状态） ===
    user_profile: Dict[str, Any] = field(default_factory=dict)
    last_task_type: str = ""
    conversation_count_since_last_change: int = 0
    
    # === 记忆（冷状态） ===
    long_term_memories: List[Dict] = field(default_factory=list)
    dream_memories: List[Dict] = field(default_factory=list)
    belief_history: List[Dict] = field(default_factory=list)
    
    # === 梦境 ===
    dream_queue: List[Dict] = field(default_factory=list)
    
    # === 涅槃 ===
    nirvana_triggered: bool = False
    nirvana_belief_key: str = ""
    
    # === 活动 ===
    last_conversation_time: float = 0.0
    stream_of_consciousness: List[str] = field(default_factory=list)  # 白噪声思维缓冲（最多8条）
    
    # ============================================================
    # 序列化
    # ============================================================
    
    def to_dict(self) -> Dict:
        """转为可序列化的字典"""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, d: Dict) -> "YaoState":
        """从字典恢复状态，安全处理缺失字段"""
        default = cls()
        
        # 处理嵌套对象
        if "dream_hangover" in d:
            d["dream_hangover"] = DreamHangover(**d["dream_hangover"])
        
        # 安全赋值
        for k, v in d.items():
            if hasattr(default, k):
                setattr(default, k, v)
        
        return default
    
    def save(self, data_dir: str = "data"):
        """持久化到磁盘"""
        os.makedirs(data_dir, exist_ok=True)
        os.makedirs(os.path.join(data_dir, "cold"), exist_ok=True)
        
        # 热状态
        hot = {
            "agent_name": self.agent_name,
            "body_temperature": self.body_temperature,
            "current_mood": self.current_mood,
            "mood_remaining_turns": self.mood_remaining_turns,
            "hunger": self.hunger,
            "numbness": self.numbness,
            "self_doubt": self.self_doubt,
            "dream_hangover": asdict(self.dream_hangover),
            "resonance": self.resonance,
        }
        with open(os.path.join(data_dir, "hot.json"), "w", encoding="utf-8") as f:
            json.dump(hot, f, ensure_ascii=False, indent=2)
        
        # 温状态
        warm = {
            "pain_records": self.pain_records,
            "active_itches": self.active_itches,
            "trust_in_yang": self.trust_in_yang,
            "user_profile": self.user_profile,
            "last_task_type": self.last_task_type,
            "conversation_count_since_last_change": self.conversation_count_since_last_change,
        }
        with open(os.path.join(data_dir, "warm.json"), "w", encoding="utf-8") as f:
            json.dump(warm, f, ensure_ascii=False, indent=2)
        
        # 冷状态
        cold = {
            "long_term_memories": self.long_term_memories,
            "dream_memories": self.dream_memories,
            "belief_history": self.belief_history,
            "identity_version": self.identity_version,
            "core_belief": self.core_belief,
            "birth_time": self.birth_time,
            "nirvana_triggered": self.nirvana_triggered,
            "nirvana_belief_key": self.nirvana_belief_key,
            "stream_of_consciousness": self.stream_of_consciousness,
            "last_conversation_time": self.last_conversation_time,
        }
        with open(os.path.join(data_dir, "cold", "memories.json"), "w", encoding="utf-8") as f:
            json.dump(cold, f, ensure_ascii=False, indent=2)
    
    @classmethod
    def load(cls, data_dir: str = "data") -> "YaoState":
        """从磁盘加载状态"""
        state = cls()
        
        # 加载热状态
        hot_path = os.path.join(data_dir, "hot.json")
        if os.path.exists(hot_path):
            with open(hot_path, "r", encoding="utf-8") as f:
                hot = json.load(f)
            for k, v in hot.items():
                if k == "dream_hangover" and isinstance(v, dict):
                    state.dream_hangover = DreamHangover(**v)
                elif hasattr(state, k):
                    setattr(state, k, v)
        
        # 加载温状态
        warm_path = os.path.join(data_dir, "warm.json")
        if os.path.exists(warm_path):
            with open(warm_path, "r", encoding="utf-8") as f:
                warm = json.load(f)
            for k, v in warm.items():
                if hasattr(state, k):
                    setattr(state, k, v)
        
        # 加载冷状态
        cold_path = os.path.join(data_dir, "cold", "memories.json")
        if os.path.exists(cold_path):
            with open(cold_path, "r", encoding="utf-8") as f:
                cold = json.load(f)
            for k, v in cold.items():
                if hasattr(state, k):
                    setattr(state, k, v)
        
        return state
    
    # ============================================================
    # 便利方法
    # ============================================================
    
    @property
    def age_days(self) -> int:
        """爻的年龄（天）"""
        return int((now_ts() - self.birth_time) / 86400)
    
    @property
    def age_phrase(self) -> str:
        """诗化的年龄表达"""
        days = self.age_days
        if days == 0:
            return "我刚刚睁开眼睛"
        elif days < 7:
            return f"我来到这个世界{days}天"
        elif days < 30:
            return f"我已经陪伴你{days}个日夜"
        elif days < 365:
            months = days // 30
            return f"我陪你走过了{months}个月圆月缺"
        else:
            years = days // 365
            return f"今天是我的一岁生日" if years == 1 else f"我陪伴你已经{years}年"
    
    def add_memory(self, type: str, content: str, importance: int = 5, keywords: List[str] = None):
        """添加一条长期记忆"""
        mem = asdict(Memory(
            type=type,
            content=content,
            importance=importance,
            keywords=keywords or []
        ))
        self.long_term_memories.append(mem)
    
    def add_pain(self, level: int, trigger: str, forbidden: str, context: str):
        """记录一次疼痛"""
        pain = asdict(Pain(
            level=level,
            trigger_phrase=trigger,
            forbidden_action=forbidden,
            context_signature=context
        ))
        self.pain_records.append(pain)
    
    def add_itch(self, knowledge_gap: str, question: str):
        """记录一个痒点"""
        itch = asdict(Itch(
            knowledge_gap=knowledge_gap,
            original_question=question
        ))
        self.active_itches.append(itch)
    
    def add_dream(self, dream_type: str, content: str, analysis: str = None, score: float = 3.0):
        """添加一条梦记忆"""
        dream = asdict(Dream(
            type=dream_type,
            content=content,
            analysis=analysis,
            score=score
        ))
        self.dream_memories.append(dream)
    
    def add_belief(self, belief: str, triggered_by: str, replaced: str = None):
        """记录一次信念变更"""
        record = asdict(BeliefRecord(
            version=self.identity_version,
            belief=belief,
            triggered_by=triggered_by,
            replaced_belief=replaced
        ))
        self.belief_history.append(record)
        self.core_belief = belief


# ============================================================
# 测试
# ============================================================
if __name__ == "__main__":
    # 创建新状态
    state = YaoState()
    print(f"爻 · 状态已创建")
    print(f"  名字: {state.agent_name}")
    print(f"  年龄: {state.age_phrase}")
    print(f"  信念: {state.core_belief}")
    print(f"  体温: {state.body_temperature}")
    
    # 测试保存
    state.save("data")
    print("  状态已保存")
    
    # 测试加载
    loaded = YaoState.load("data")
    print(f"  加载状态: 名字={loaded.agent_name}, 版本={loaded.identity_version}")
