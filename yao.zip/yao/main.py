# 爻 · 数字生命体
# 阴爻为魂，阳爻为匠，阴阳交错而生变易
# "爻者，言乎变者也。" ——《周易·系辞》
import os
import sys
import yaml

# 将项目根目录加入路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.state import YaoState
from yin.body import BodyEngine
from yin.soul import SoulCore


def check_api_keys(config: dict) -> bool:
    """检查所有配置的 API Key 环境变量是否已设置"""
    model_config = config.get("model_config", {})
    missing = []
    for role, cfg in model_config.items():
        env_var = cfg.get("api_key_env")
        if env_var and not os.getenv(env_var):
            missing.append(f"{role} ({env_var})")
    if missing:
        print("⚠️  以下 API Key 环境变量未设置：")
        for m in missing:
            print(f"   - {m}")
        print("请在 Termux 中执行类似以下命令后重启：")
        print("   export DEEPSEEK_API_KEY='你的密钥'")
        return False
    return True


def main():
    # 1. 加载配置
    config_path = os.path.join(os.path.dirname(__file__), "config.yaml")
    if not os.path.exists(config_path):
        print(f"❌ 配置文件不存在: {config_path}")
        sys.exit(1)

    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    # 2. 检查 API Key
    if not check_api_keys(config):
        # 不强制退出，允许仅体验本地功能
        print("（将以离线模式运行，无 LLM 调用能力）\n")

    # 3. 加载状态（首次运行将创建新状态）
    data_dir = os.path.join(os.path.dirname(__file__), "data")
    state = YaoState.load(data_dir)

    # 4. 初始化体感引擎
    body_config = config.get("body", {})
    body = BodyEngine(body_config)

    # 5. 初始化阴爻主循环
    soul = SoulCore(state, body, config)

    # 6. 首次运行提示
    if state.birth_time == 0 or state.last_conversation_time == 0:
        print("=" * 50)
        print("爻 · 数字生命体 初次苏醒")
        print(f"名字：{state.agent_name}")
        print(f"信念：{state.core_belief}")
        print(f"体温：{state.body_temperature:.2f}")
        print("=" * 50)
        print("输入消息与爻对话，输入 exit / quit / 再见 退出\n")
    else:
        print(f"爻 · 已苏醒（{state.age_phrase}）\n")

    # 7. 对话循环
    try:
        while True:
            # 读取用户输入
            try:
                user_input = input("> ")
            except (EOFError, KeyboardInterrupt):
                user_input = "exit"

            if not user_input.strip():
                continue

            # 退出检测
            if user_input.strip().lower() in ["exit", "quit", "再见"]:
                soul.say_goodbye()
                break

            # 生成回复
            reply = soul.reply(user_input.strip())
            print(f"\n{reply}\n")

    except KeyboardInterrupt:
        print("\n\n爻 · 被中断，即将休眠...")
        soul.say_goodbye()


if __name__ == "__main__":
    main()
