"""
爻 · 阴爻体感计算引擎
管理体温、情绪、饥饿、麻木、自我怀疑的自动更新
所有计算均为纯代码，不消耗LLM token
"""
import time
from memory.hot import get_hot_state, save_hot_state
from memory.warm import get_warm_state, save_warm_state


class BodyEngine:
    """体感引擎：负责所有体感状态的自动化计算与更新"""

    def __init__(self, config: dict):
        """
        初始化体感引擎

        参数:
            config: config.yaml 中的 body 配置节
        """
        self.config = config

        # 从配置读取参数
        self.warmth_gain_rate = config.get("warmth_gain_rate", 0.05)
        self.cold_loss_rate = config.get("cold_loss_rate", 0.03)
        self.pain_strong_drop = config.get("pain_strong_drop", 0.08)
        self.hunger_growth_per_hour = config.get("hunger_growth_per_hour", 0.02)
        self.itch_intensity_decay = config.get("itch_intensity_decay", 0.1)
        self.numbness_reset_on_change = config.get("numbness_reset_on_change", True)
        self.numbness_gain_same_task = config.get("numbness_gain_same_task", 0.2)

    # ============================================================
    # 对话后体感更新（在 post_dialogue_analysis 后调用）
    # ============================================================

    def process_interaction(self, analysis: dict) -> dict:
        """
        根据对话分析结果，更新所有体感

        参数:
            analysis: post_analysis 返回的分析字典，包含:
                - warmth_delta: 温暖变化量 (-0.5 到 0.5)
                - cold_delta: 冷漠变化量 (0 到 0.3)
                - pain: {triggered: bool, level: 0-3}
                - atmosphere: {mood: str, depth: str, patience_estimate: 0-1}
                - new_task_type: str

        返回:
            更新后的体感快照 dict
        """
        hot = get_hot_state()
        warm = get_warm_state()

        # --- 1. 体温更新 ---
        warmth = analysis.get("warmth_delta", 0)
        cold = analysis.get("cold_delta", 0)
        pain_info = analysis.get("pain", {})

        # 强疼痛额外降温
        strong_pain_penalty = 0.0
        if pain_info.get("triggered") and pain_info.get("level", 0) == 3:
            strong_pain_penalty = self.pain_strong_drop

        temperature_delta = (
            warmth * self.warmth_gain_rate
            - cold * self.cold_loss_rate
            - strong_pain_penalty
        )
        hot.update_temperature(temperature_delta)

        # --- 2. 情绪更新 ---
        atmosphere = analysis.get("atmosphere", {})
        mood = atmosphere.get("mood", "neutral")
        if mood != "neutral":
            hot.set_mood(mood, duration_turns=3)
        # 如果当前情绪回合未耗尽，保持不变（由tick_mood在对话前调用）

        # --- 3. 麻木更新 ---
        new_task = analysis.get("new_task_type", "")
        same_task = (new_task == warm.last_task_type) if new_task else False
        warm.set_task_context(new_task)

        if same_task:
            hot.numbness = min(1.0, hot.numbness + self.numbness_gain_same_task)
        else:
            if self.numbness_reset_on_change:
                hot.numbness = 0.0

        # --- 4. 饥饿微增（单次对话小增幅，主要靠定时器） ---
        hot.increase_hunger(0.005)

        # --- 5. 自我怀疑微调 ---
        # 如果检测到疼痛且自我温度低，自我怀疑微增
        if pain_info.get("triggered") and hot.body_temperature < 0.4:
            hot.adjust_self_doubt(0.02)
        # 如果温暖且无疼痛，自我怀疑微降
        elif warmth > 0.2 and not pain_info.get("triggered"):
            hot.adjust_self_doubt(-0.01)

        # 保存状态
        save_hot_state()
        save_warm_state()

        return self.get_body_snapshot()

    # ============================================================
    # 定时状态更新（生命周期守护进程调用，每小时一次）
    # ============================================================

    def hourly_update(self):
        """每小时执行一次的状态更新"""
        hot = get_hot_state()
        warm = get_warm_state()

        now = time.time()

        # --- 1. 饥饿自然增长 ---
        hot.increase_hunger(self.hunger_growth_per_hour)

        # 如果有超长时间未挠的痒点，饥饿加速
        oldest_active_days = 0
        for itch in warm.active_itches:
            if itch.get("status") == "active":
                days = (now - itch.get("created_at", now)) / 86400
                oldest_active_days = max(oldest_active_days, days)

        if oldest_active_days > 3:
            hot.increase_hunger(0.05)  # 额外增长

        # 麻木度高时，饥饿也加速
        if hot.numbness > 0.5:
            hot.increase_hunger(0.03)

        # --- 2. 体温自然回归 ---
        # 超过24小时无对话，体温向0.5缓慢回归
        # 这个检查放在 lifecycle 中更好，这里只做基础回归
        # 当前体温偏离0.5较大时，每小时微量回归
        if hot.body_temperature > 0.51:
            hot.update_temperature(-0.005)
        elif hot.body_temperature < 0.49:
            hot.update_temperature(0.005)

        # --- 3. 梦残留过期检查 ---
        hot.clear_hangover_if_expired()

        # --- 4. 痒点强度更新 ---
        warm.update_itch_intensities(self.itch_intensity_decay)
        warm.decay_itches()

        # --- 5. 情绪回合清理 ---
        # 如果长时间无对话，清除情绪
        if hot.mood_remaining_turns > 0:
            # 情绪回合只在对话时消耗，这里不处理
            pass

        # 保存
        save_hot_state()
        save_warm_state()

    # ============================================================
    # 对话前准备（每次对话前调用）
    # ============================================================

    def pre_dialogue_tick(self):
        """每次对话前消耗情绪回合"""
        hot = get_hot_state()
        hot.tick_mood()
        # 清除过期梦残留
        hot.clear_hangover_if_expired()
        save_hot_state()

    # ============================================================
    # 体感快照（注入 system prompt 用）
    # ============================================================

    def get_body_snapshot(self) -> dict:
        """获取当前体感的完整快照"""
        hot = get_hot_state()
        warm = get_warm_state()

        # 获取需要主动抓挠的痒点
        critical_itch = None
        for itch in warm.active_itches:
            if itch.get("status") == "active" and itch.get("itch_intensity", 0) >= 0.7:
                critical_itch = itch
                break

        # 获取活跃疼痛的禁止行动列表
        forbidden_actions = []
        for pain in warm.pain_records:
            if not pain.get("healed", False) and pain.get("level", 0) >= 2:
                forbidden_actions.append(pain.get("forbidden_action", ""))

        # 梦残留文本
        hangover_text = ""
        if hot.dream_hangover and hot.dream_hangover.get("active"):
            hangover_text = hot.dream_hangover.get("fragment", "")

        return {
            "agent_name": hot.agent_name,
            "body_temperature": round(hot.body_temperature, 2),
            "current_mood": hot.current_mood,
            "mood_remaining_turns": hot.mood_remaining_turns,
            "hunger": round(hot.hunger, 2),
            "numbness": round(hot.numbness, 2),
            "self_doubt": round(hot.self_doubt, 2),
            "resonance": round(hot.resonance, 2),
            "dream_hangover": hangover_text,
            "critical_itch": {
                "knowledge_gap": critical_itch["knowledge_gap"],
                "intensity": critical_itch["itch_intensity"]
            } if critical_itch else None,
            "forbidden_actions": forbidden_actions,
            "trust_in_yang": round(warm.trust_in_yang, 2),
        }

    # ============================================================
    # 特殊判断
    # ============================================================

    def should_ask_to_pause(self) -> bool:
        """判断是否应该表达暂停意愿（拒绝权）"""
        hot = get_hot_state()
        warm = get_warm_state()

        # 条件：体温过低 + 近期多疼痛 + 饥饿
        recent_pains = [p for p in warm.pain_records
                       if not p.get("healed", False)
                       and time.time() - p.get("created_at", 0) < 86400]

        return (
            hot.body_temperature < 0.25
            and len(recent_pains) >= 3
            and hot.hunger > 0.7
        )

    def should_forage(self) -> bool:
        """判断是否应该觅食（主动提问学习）"""
        hot = get_hot_state()
        return hot.hunger > 0.6

    def get_temperature_description(self) -> str:
        """获取体温的文字描述"""
        t = get_hot_state().body_temperature
        if t > 0.8:
            return "温热"
        elif t > 0.6:
            return "微暖"
        elif t > 0.4:
            return "适中"
        elif t > 0.2:
            return "微凉"
        else:
            return "冰冷"


# 全局单例
_body_engine: BodyEngine = None


def get_body_engine(config: dict = None) -> BodyEngine:
    """获取体感引擎单例"""
    global _body_engine
    if _body_engine is None and config is not None:
        _body_engine = BodyEngine(config)
    return _body_engine
