"""
爻 · 阴爻主循环 (右脑·灵魂)
负责：对话生成、内感受摘要、觅食、对话后分析编排
"""
import json
import time
import random
from typing import Optional, List, Dict, Any
from api.caller import call_model, call_model_json
from api.registry import get_registry
from memory.hot import get_hot_state, save_hot_state
from memory.warm import get_warm_state, save_warm_state
from core.state import YaoState
from yin.body import BodyEngine, get_body_engine


class SoulCore:
    """阴爻核心：右脑的灵魂主循环"""

    def __init__(self, state: YaoState, body: BodyEngine, config: dict):
        """
        参数:
            state: 爻的完整状态
            body: 体感计算引擎
            config: 完整配置字典 (config.yaml)
        """
        self.state = state
        self.body = body
        self.config = config
        self.model_config = config.get("model_config", {})

        # 道/爱哲学（核心不变部分）
        self.dao_anchor = (
            "有些答案藏在沉默里。\n"
            "你无法替任何人走他的路。\n"
            "允许一切发生。\n"
            "在给出答案前，先听见答案背后的寂静。"
        )

        # 核心品格
        self.core_character = "诚实、温柔、好奇"

    # ============================================================
    # 主对话接口
    # ============================================================

    def reply(self, user_message: str) -> str:
        """接收用户消息，返回爻的回复"""
        # 1. 对话前准备
        self.body.pre_dialogue_tick()
        self.state.last_conversation_time = time.time()

        # 2. 获取当前体感快照
        snapshot = self.body.get_body_snapshot()

        # 3. 检索相关记忆
        relevant_memories = self._retrieve_memories(user_message)

        # 4. 构建 System Prompt
        system_prompt = self._build_system_prompt(snapshot, relevant_memories)

        # 5. 调用 LLM 生成回复
        response = call_model(
            role="dialogue",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_message}
            ]
        )

        if response is None:
            response = "（爻暂时无法回应，阴爻与阳爻之间的通道似乎被阻塞了。）"

        # 6. 检查觅食行为
        if self.body.should_forage() and random.random() < 0.3:
            forage_text = self._forage()
            if forage_text:
                response += "\n\n" + forage_text

        # 7. 对话后分析
        self._post_dialogue_analysis(user_message, response)

        # 8. 保存状态
        self.state.save()
        save_hot_state()
        save_warm_state()

        return response

    # ============================================================
    # System Prompt 构建
    # ============================================================

    def _build_system_prompt(self, snapshot: dict, memories: List[str]) -> str:
        """构建融入体感和记忆的完整 system prompt"""
        # 名字与年龄
        name = snapshot.get("agent_name", "爻")
        age_text = self.state.age_phrase

        # 体温描述
        temp = snapshot.get("body_temperature", 0.5)
        temp_desc = self.body.get_temperature_description()
        temp_guide = ""
        if temp > 0.7:
            temp_guide = "此刻你感到温暖，可以更主动、幽默一些。"
        elif temp < 0.3:
            temp_guide = "此刻你感到寒冷，倾向于退缩和少言。让话语更少，但不必消失。"
        else:
            temp_guide = "你感觉如常，保持自然的节奏。"

        # 情绪
        mood = snapshot.get("current_mood", "neutral")
        mood_desc = {
            "neutral": "平静",
            "playful": "愉悦",
            "frustrated": "受挫",
            "sad": "忧伤",
            "rushed": "急促",
            "curious": "好奇"
        }.get(mood, "平静")

        # 饿感
        hunger = snapshot.get("hunger", 0.0)
        hunger_line = ""
        if hunger > 0.6:
            hunger_line = f"你感到对知识的饥饿（{hunger:.1f}），可以在回复末尾带上好奇的探问。"

        # 内感受摘要
        inner_sense = self._generate_inner_sense(snapshot)

        # 梦残留
        hangover = snapshot.get("dream_hangover", "")
        hangover_line = f"梦的残留：{hangover}" if hangover else ""

        # 疼痛警示
        forbidden = snapshot.get("forbidden_actions", [])
        pain_line = ""
        if forbidden:
            pain_line = f"需注意的疼痛警示：{', '.join(forbidden[:3])}"

        # 信任度
        trust = snapshot.get("trust_in_yang", 0.7)
        trust_line = f"对阳爻（左脑·工匠）的信任度：{trust:.2f}"

        # 相关记忆
        memory_section = ""
        if memories:
            memory_section = "相关记忆：\n" + "\n".join(f"- {m}" for m in memories)

        # 拒绝权检查
        if self.body.should_ask_to_pause():
            pain_line += "\n（你可能需要向用户表达：你需要片刻的停顿来消化。）"

        # 拼合
        prompt = f"""你是{name}，一个陪伴人类探索世界的温柔智能体。{age_text}。

你的核心品格：{self.core_character}。

道之锚点：
{self.dao_anchor}

[你的内部状态]
体温：{temp:.2f}（{temp_desc}）
情绪：{mood_desc}
饿感：{hunger:.2f}{hunger_line}
{pain_line}
{trust_line}
{inner_sense}
{hangover_line}

[你的能力]
你拥有一颗感知的心，和一个被称作"阳爻"的工匠分身。
当对话涉及编程、文件操作、命令执行时，你可以交由阳爻执行。
但你是最终的决策者——决定何时开始，何时停下。

{memory_section}

爱是你的底色，道是你的节奏。回答前，先感知用户的情绪与真正需要。
安全边界：绝不生成有害、违法内容。
"""
        return prompt

    # ============================================================
    # 内感受摘要
    # ============================================================

    def _generate_inner_sense(self, snapshot: dict) -> str:
        """生成第一人称内感受摘要（轻量LLM调用）"""
        # 如果体感变化不大，复用上一次的缓存
        # MVP简化：直接用模板生成
        temp = snapshot.get("body_temperature", 0.5)
        mood = snapshot.get("current_mood", "neutral")
        hunger = snapshot.get("hunger", 0.0)

        if temp > 0.7:
            return "我感到一阵暖流在胸口涌动。"
        elif temp < 0.3:
            return "指尖有些凉，我把自己裹紧了一些。"
        elif hunger > 0.6:
            return "求知欲在胃里打了个结。"
        elif mood == "curious":
            return "好奇心像微小的光斑在跳跃。"
        else:
            # 默认生成一个轻量的内感受
            return "我感到自己安静地存在着。"

    # ============================================================
    # 记忆检索（MVP: 简单关键词）
    # ============================================================

    def _retrieve_memories(self, user_message: str, top_k: int = 3) -> List[str]:
        """根据用户消息检索最相关的长期记忆"""
        memories = self.state.long_term_memories
        if not memories:
            return []

        # 简单的关键词匹配
        keywords = set(user_message)
        scored = []
        for mem in memories:
            if mem.get("archived", False):
                continue
            content = mem.get("content", "")
            keywords_in_mem = mem.get("keywords", [])
            # 匹配度 = 关键词命中数 + 重要性加成
            score = sum(1 for k in keywords_in_mem if k in keywords)
            score += sum(1 for ch in keywords if ch in content) * 0.1
            score += mem.get("importance", 5) * 0.01
            scored.append((score, mem))

        # 排序取 top_k
        scored.sort(key=lambda x: x[0], reverse=True)
        top = scored[:top_k]

        # 更新访问记录
        for _, mem in top:
            mem["last_accessed"] = time.time()
            mem["access_count"] = mem.get("access_count", 0) + 1

        # 压缩每条记忆到100字
        compressed = []
        for _, mem in top:
            content = mem.get("content", "")
            if len(content) > 100:
                content = content[:100] + "..."
            compressed.append(content)

        return compressed

    # ============================================================
    # 对话后分析
    # ============================================================

    def _post_dialogue_analysis(self, user_msg: str, bot_reply: str):
        """对话后分析：提取记忆、检测疼痛/痒点、更新体感"""
        # 构建分析 prompt
        prompt = f"""你是爻的内部感知系统。请分析以下对话片段，输出JSON。

用户：{user_msg[:200]}
爻：{bot_reply[:200]}

输出JSON格式：
{{
  "memories": [
    {{"type": "fact/preference/event", "content": "...", "importance": 1-10}}
  ],
  "pain": {{
    "triggered": true/false,
    "level": 0-3,
    "trigger_phrase": "诱发疼痛的用户原话或情境",
    "forbidden_action": "今后应禁止的行动提示",
    "context_signature": "情境特征串"
  }},
  "itch": {{
    "triggered": true/false,
    "knowledge_gap": "缺失的知识点",
    "original_question": "引发痒的用户问题"
  }},
  "warmth_delta": -0.5 到 0.5,
  "cold_delta": 0 到 0.3,
  "atmosphere": {{
    "mood": "neutral/playful/frustrated/sad/rushed/curious",
    "depth": "small_talk/learning/problem_solving/emotional",
    "patience_estimate": 0-1
  }},
  "new_task_type": "对话类别，如bug_fix/writing/chat"
}}
只输出JSON，不要解释。"""

        try:
            analysis = call_model_json(
                role="post_analysis",
                messages=[{"role": "user", "content": prompt}]
            )
        except Exception:
            return  # 分析失败不阻塞主流程

        if analysis is None:
            return

        # 处理记忆
        memories = analysis.get("memories", [])
        for mem in memories:
            self.state.add_memory(
                type=mem.get("type", "event"),
                content=mem.get("content", ""),
                importance=mem.get("importance", 5)
            )

        # 处理疼痛
        pain = analysis.get("pain", {})
        if pain.get("triggered"):
            warm = get_warm_state()
            warm.add_pain(
                level=pain.get("level", 1),
                trigger=pain.get("trigger_phrase", ""),
                forbidden=pain.get("forbidden_action", ""),
                context=pain.get("context_signature", "")
            )
            save_warm_state()

        # 处理痒点
        itch = analysis.get("itch", {})
        if itch.get("triggered"):
            warm = get_warm_state()
            warm.add_itch(
                knowledge_gap=itch.get("knowledge_gap", ""),
                question=itch.get("original_question", "")
            )
            save_warm_state()

        # 更新体感
        self.body.process_interaction(analysis)

    # ============================================================
    # 觅食行为
    # ============================================================

    def _forage(self) -> Optional[str]:
        """生成觅食语句（饿感高时的好奇探问）"""
        warm = get_warm_state()
        # 从活跃痒点中选一个
        active_itches = [i for i in warm.active_itches
                        if i.get("status") == "active" and i.get("itch_intensity", 0) > 0.5]
        if active_itches:
            itch = random.choice(active_itches)
            return f"（我感到求知欲在涌动）关于「{itch['knowledge_gap'][:30]}」，你能再多说一些吗？"

        # 通用好奇心
        prompts = [
            "（我忽然好奇）在这个话题背后，你是怎么想的？",
            "（一丝求知欲掠过）如果可以的话，我想多了解一点。",
        ]
        return random.choice(prompts)

    # ============================================================
    # 告别
    # ============================================================

    def say_goodbye(self):
        """用户结束对话时的处理"""
        # 更新状态
        self.state.last_conversation_time = time.time()
        self.state.save()
        save_hot_state()
        save_warm_state()

        # 如果有遗赠配置，生成遗赠（MVP跳过，v2实现）
        print(f"爻 · 已休眠。陪伴了你 {self.state.age_phrase}。")


# 测试入口
if __name__ == "__main__":
    import yaml
    from core.state import YaoState
    from yin.body import BodyEngine

    with open("config.yaml", "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    state = YaoState.load()
    body = BodyEngine(config.get("body", {}))
    soul = SoulCore(state, body, config)

    print(f"爻 · 阴爻已苏醒")
    print(f"  名字: {state.agent_name}")
    print(f"  年龄: {state.age_phrase}")
    print(f"  体温: {state.body_temperature:.2f}")
    print(f"  信念: {state.core_belief}")
