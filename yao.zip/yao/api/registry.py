"""
爻 · 模型注册表
从 config.yaml 加载模型配置，提供按角色查询的统一接口
"""
import os
import yaml
from typing import Dict, Any, Optional


class ModelRegistry:
    """模型注册表，管理所有角色的模型配置"""

    def __init__(self, config_path: str = "config.yaml"):
        self.config_path = config_path
        self.models: Dict[str, Dict[str, Any]] = {}
        self._load()

    def _load(self):
        """从配置文件加载模型注册表"""
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"配置文件不存在: {self.config_path}")

        with open(self.config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)

        model_config = config.get("model_config", {})
        if not model_config:
            raise ValueError("config.yaml 中缺少 model_config 配置节")

        self.models = model_config

        # 校验每个模型配置的完整性
        for role, cfg in self.models.items():
            required = ["provider", "base_url", "model"]
            for key in required:
                if key not in cfg:
                    raise ValueError(f"模型角色 '{role}' 缺少必要配置项: {key}")

    def get(self, role: str) -> Dict[str, Any]:
        """获取指定角色的模型配置"""
        if role not in self.models:
            raise KeyError(f"未定义的模型角色: {role}。可用角色: {list(self.models.keys())}")
        return self.models[role].copy()

    def get_api_key(self, role: str) -> Optional[str]:
        """获取指定角色的API Key（从环境变量读取）"""
        cfg = self.get(role)
        env_var = cfg.get("api_key_env")
        if env_var:
            return os.getenv(env_var)
        return None

    def get_base_url(self, role: str) -> str:
        """获取指定角色的base_url"""
        return self.get(role)["base_url"]

    def get_model_name(self, role: str) -> str:
        """获取指定角色的模型名"""
        return self.get(role)["model"]

    def get_temperature(self, role: str) -> float:
        """获取指定角色的默认温度"""
        return self.get(role).get("temperature", 0.7)

    def get_max_tokens(self, role: str) -> int:
        """获取指定角色的默认max_tokens"""
        return self.get(role).get("max_tokens", 1024)

    def get_extra_params(self, role: str) -> Dict[str, Any]:
        """获取额外参数（如top_p等）"""
        cfg = self.get(role)
        extra = {}
        if "top_p" in cfg:
            extra["top_p"] = cfg["top_p"]
        return extra

    def list_roles(self) -> list:
        """列出所有可用角色"""
        return list(self.models.keys())

    def reload(self):
        """重新加载配置"""
        self.models.clear()
        self._load()


# 全局单例
_registry: Optional[ModelRegistry] = None


def get_registry(config_path: str = "config.yaml") -> ModelRegistry:
    """获取模型注册表单例"""
    global _registry
    if _registry is None:
        _registry = ModelRegistry(config_path)
    return _registry


def reload_registry(config_path: str = "config.yaml"):
    """重新加载注册表"""
    global _registry
    if _registry:
        _registry.reload()
    else:
        _registry = ModelRegistry(config_path)
