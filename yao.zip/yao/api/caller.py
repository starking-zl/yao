"""
爻 · 统一模型调用接口
所有LLM调用走此模块，支持角色路由、参数合并、错误重试
"""
import time
from typing import List, Dict, Any, Optional
from openai import OpenAI
from .registry import get_registry


def call_model(
    role: str,
    messages: List[Dict[str, str]],
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    extra_params: Optional[Dict[str, Any]] = None,
    max_retries: int = 2,
    retry_delay: float = 1.0,
    config_path: str = "config.yaml"
) -> Optional[str]:
    """
    统一的模型调用接口

    参数:
        role: 模型角色 (dialogue/craftsman/dream_generation/dream_analysis/
              nirvana/inner_voice/post_analysis)
        messages: 标准的消息列表 [{"role": "user", "content": "..."}]
        temperature: 覆盖默认温度
        max_tokens: 覆盖默认最大token数
        extra_params: 额外参数 (如 {"top_p": 0.99})
        max_retries: 最大重试次数
        retry_delay: 重试间隔秒数
        config_path: 配置文件路径

    返回:
        模型生成的文本，失败返回 None
    """
    registry = get_registry(config_path)

    # 获取配置
    cfg = registry.get(role)
    api_key = registry.get_api_key(role)

    # 合并参数：调用时传入的 > 配置文件的 > 默认
    final_temperature = temperature if temperature is not None else cfg.get("temperature", 0.7)
    final_max_tokens = max_tokens if max_tokens is not None else cfg.get("max_tokens", 1024)
    final_extra = {}
    if "top_p" in cfg:
        final_extra["top_p"] = cfg["top_p"]
    if extra_params:
        final_extra.update(extra_params)

    # 创建客户端
    client = OpenAI(
        base_url=cfg["base_url"],
        api_key=api_key if api_key else "not-needed"
    )

    # 构建请求参数
    request_params = {
        "model": cfg["model"],
        "messages": messages,
        "temperature": final_temperature,
        "max_tokens": final_max_tokens,
    }
    if final_extra:
        request_params.update(final_extra)

    # 重试循环
    last_error = None
    for attempt in range(max_retries + 1):
        try:
            response = client.chat.completions.create(**request_params)
            content = response.choices[0].message.content
            return content

        except Exception as e:
            last_error = e
            error_str = str(e).lower()

            # 不可重试的错误
            if any(keyword in error_str for keyword in [
                "api key", "authentication", "authorization",
                "not found", "invalid", "insufficient_quota"
            ]):
                print(f"[call_model] 不可重试错误 (role={role}): {e}")
                break

            # 可重试的错误（超时、服务器错误、频率限制）
            if attempt < max_retries:
                wait_time = retry_delay * (2 ** attempt)
                print(f"[call_model] 重试 {attempt + 1}/{max_retries} (role={role}), "
                      f"等待 {wait_time:.1f}s: {e}")
                time.sleep(wait_time)
            else:
                print(f"[call_model] 重试耗尽 (role={role}): {e}")

    print(f"[call_model] 调用失败 (role={role}): {last_error}")
    return None


def call_model_json(
    role: str,
    messages: List[Dict[str, str]],
    temperature: Optional[float] = None,
    max_tokens: Optional[int] = None,
    config_path: str = "config.yaml"
) -> Optional[Dict[str, Any]]:
    """
    调用模型并期望返回JSON格式
    在请求中添加 response_format 参数（部分模型支持）
    """
    import json

    # 在system prompt中追加JSON格式要求
    modified_messages = messages.copy()
    if modified_messages and modified_messages[0].get("role") == "system":
        modified_messages[0]["content"] += "\n请仅输出JSON，不要包含任何解释。"
    else:
        modified_messages.insert(0, {
            "role": "system",
            "content": "请仅输出JSON，不要包含任何解释。"
        })

    text = call_model(
        role=role,
        messages=modified_messages,
        temperature=temperature if temperature is not None else 0.1,
        max_tokens=max_tokens,
        config_path=config_path
    )

    if text is None:
        return None

    # 尝试解析JSON（处理可能的markdown包装）
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # 尝试提取第一个完整的JSON对象
        depth = 0
        start = -1
        for i, ch in enumerate(text):
            if ch == '{':
                if depth == 0:
                    start = i
                depth += 1
            elif ch == '}':
                depth -= 1
                if depth == 0 and start >= 0:
                    try:
                        return json.loads(text[start:i+1])
                    except json.JSONDecodeError:
                        continue
        print(f"[call_model_json] JSON解析失败，原始文本: {text[:200]}")
        return None
