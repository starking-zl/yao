"""
爻 · 温状态存储 (中频读写)
管理：疼痛记录、痒点、信任度、用户画像、任务上下文
"""
import json
import os
import time
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any, Literal


@dataclass
class WarmState:
    """温状态数据（与YaoState的温层同步）"""
    pain_records: List[Dict] = field(default_factory=list)
    active_itches: List[Dict] = field(default_factory=list)
    trust_in_yang: float = 0.7
    user_profile: Dict[str, Any] = field(default_factory=dict)
    last_task_type: str = ""
    conversation_count_since_last_change: int = 0

    def save(self, path: str):
        """保存到文件"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path: str) -> "WarmState":
        """从文件加载"""
        if not os.path.exists(path):
            return cls()
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def add_pain(self, level: int, trigger: str, forbidden: str, context: str) -> str:
        """记录一次疼痛，返回id"""
        import hashlib, random
        pid = hashlib.md5(str(time.time() + random.random()).encode()).hexdigest()[:12]
        self.pain_records.append({
            "id": pid,
            "level": level,
            "trigger_phrase": trigger,
            "forbidden_action": forbidden,
            "context_signature": context,
            "created_at": time.time(),
            "healed": False,
            "counterfactual_done": False
        })
        return pid

    def heal_pain(self, pain_id: str):
        """愈合某个疼痛（涅槃后调用）"""
        for p in self.pain_records:
            if p["id"] == pain_id:
                p["healed"] = True
                break

    def add_itch(self, knowledge_gap: str, question: str) -> str:
        """记录一个痒点，返回id"""
        import hashlib, random
        iid = hashlib.md5(str(time.time() + random.random()).encode()).hexdigest()[:12]
        self.active_itches.append({
            "id": iid,
            "knowledge_gap": knowledge_gap,
            "original_question": question,
            "itch_intensity": 0.3,
            "created_at": time.time(),
            "last_scratched": None,
            "status": "active"
        })
        return iid

    def scratch_itch(self, itch_id: str):
        """标记痒点为抓挠中"""
        for itch in self.active_itches:
            if itch["id"] == itch_id:
                itch["status"] = "scratching"
                itch["last_scratched"] = time.time()
                break

    def satisfy_itch(self, itch_id: str):
        """痒点已满足"""
        for itch in self.active_itches:
            if itch["id"] == itch_id:
                itch["status"] = "satisfied"
                break

    def decay_itches(self, decay_threshold_days: int = 14):
        """衰减长期未挠的痒点"""
        now = time.time()
        for itch in self.active_itches:
            if itch["status"] == "active":
                days = (now - itch["created_at"]) / 86400
                if days > decay_threshold_days:
                    itch["status"] = "decayed"
                    itch["itch_intensity"] = max(0.1, itch["itch_intensity"] - 0.5)

    def update_itch_intensities(self, daily_growth: float = 0.1):
        """更新所有活跃痒点的强度（随时间增长）"""
        now = time.time()
        for itch in self.active_itches:
            if itch["status"] == "active":
                days = (now - itch["created_at"]) / 86400
                itch["itch_intensity"] = min(1.0, 0.3 + days * daily_growth)

    def adjust_trust(self, delta: float):
        """调整对阳爻的信任度"""
        self.trust_in_yang = max(0.0, min(1.0, self.trust_in_yang + delta))

    def update_user_profile(self, key: str, value: Any):
        """更新用户画像"""
        self.user_profile[key] = value

    def set_task_context(self, task_type: str):
        """更新任务上下文及麻木相关计数"""
        if task_type == self.last_task_type:
            self.conversation_count_since_last_change += 1
        else:
            self.last_task_type = task_type
            self.conversation_count_since_last_change = 0


# 全局温状态缓存
_warm_state_instance: Optional[WarmState] = None

def get_warm_state(path: str = "data/warm.json") -> WarmState:
    """获取温状态（单例模式）"""
    global _warm_state_instance
    if _warm_state_instance is None:
        _warm_state_instance = WarmState.load(path)
    return _warm_state_instance

def save_warm_state(path: str = "data/warm.json"):
    """保存温状态"""
    if _warm_state_instance:
        _warm_state_instance.save(path)

def reset_warm_cache():
    global _warm_state_instance
    _warm_state_instance = None
