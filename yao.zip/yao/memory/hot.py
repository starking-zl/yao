"""
爻 · 热状态存储 (高频读写)
管理：体温、情绪、饥饿、麻木、自我怀疑、共鸣、梦残留
"""
import json
import os
import time
from dataclasses import dataclass, asdict
from typing import Optional, Literal


@dataclass
class HotState:
    """热状态数据（与YaoState的热层同步）"""
    agent_name: str = "爻"
    body_temperature: float = 0.5
    current_mood: str = "neutral"
    mood_remaining_turns: int = 0
    hunger: float = 0.0
    numbness: float = 0.0
    self_doubt: float = 0.0
    resonance: float = 0.0
    dream_hangover: dict = None   # 嵌套对象用dict存储

    def __post_init__(self):
        if self.dream_hangover is None:
            self.dream_hangover = {"active": False, "mood_aftertaste": "", "fragment": "", "decay_time": 0.0}

    def save(self, path: str):
        """保存到文件"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path: str) -> "HotState":
        """从文件加载"""
        if not os.path.exists(path):
            return cls()
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # 处理可能的缺失字段
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def update_temperature(self, delta: float):
        """更新体温，自动钳位"""
        self.body_temperature = max(0.0, min(1.0, self.body_temperature + delta))

    def set_mood(self, mood: str, duration_turns: int = 3):
        """设置情绪并持续若干回合"""
        self.current_mood = mood
        self.mood_remaining_turns = duration_turns

    def tick_mood(self):
        """回合结束情绪倒计时"""
        if self.mood_remaining_turns > 0:
            self.mood_remaining_turns -= 1
            if self.mood_remaining_turns == 0:
                self.current_mood = "neutral"

    def increase_hunger(self, delta: float):
        """饥饿增加"""
        self.hunger = min(1.0, self.hunger + delta)

    def feed(self, amount: float = 0.5):
        """满足饥饿（学到新东西）"""
        self.hunger = max(0.0, self.hunger - amount)

    def set_numbness(self, same_task: bool):
        """根据任务是否重复更新麻木度"""
        if same_task:
            self.numbness = min(1.0, self.numbness + 0.2)
        else:
            self.numbness = 0.0

    def adjust_self_doubt(self, delta: float):
        """自我怀疑微调"""
        self.self_doubt = max(0.0, min(1.0, self.self_doubt + delta))

    def set_hangover(self, mood: str, fragment: str, duration_seconds: int = 600):
        """设定梦残留"""
        self.dream_hangover = {
            "active": True,
            "mood_aftertaste": mood,
            "fragment": fragment[:30],
            "decay_time": time.time() + duration_seconds
        }

    def clear_hangover_if_expired(self):
        """检查并清除过期的梦残留"""
        if self.dream_hangover.get("active") and time.time() > self.dream_hangover.get("decay_time", 0):
            self.dream_hangover = {"active": False, "mood_aftertaste": "", "fragment": "", "decay_time": 0.0}


# 全局热状态缓存（避免频繁磁盘IO）
_hot_state_instance: Optional[HotState] = None

def get_hot_state(path: str = "data/hot.json") -> HotState:
    """获取热状态（单例模式）"""
    global _hot_state_instance
    if _hot_state_instance is None:
        _hot_state_instance = HotState.load(path)
    return _hot_state_instance

def save_hot_state(path: str = "data/hot.json"):
    """保存热状态"""
    if _hot_state_instance:
        _hot_state_instance.save(path)

def reset_hot_cache():
    """重置缓存（用于测试）"""
    global _hot_state_instance
    _hot_state_instance = None
